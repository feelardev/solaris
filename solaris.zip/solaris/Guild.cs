﻿using Newtonsoft.Json.Linq;
using Solaris.API;
using System;
using System.Drawing;
using Console = Colorful.Console;

public static class Guild
{
    public static void MsgInEveryChannel(string token, ulong? gid, string message)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/channels", "GET", token)))
            {
                if (item.type == "0")
                {
                    Request.Send($"/channels/{item.id}/messages", "POST", token, "{\"content\":\"" + message + "\"}");
                    Config.Sleep(Config.Wait.Short);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void LeaveDeleteGuild(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            try
            {
                Request.Send($"/guilds/{gid}", "DELETE", token);
            }
            catch
            {
                Request.Send($"/users/@me/guilds/{gid}", "DELETE", token);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void GuildInformation(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            string json = Request.Send($"/guilds/{gid}", "GET", token);
            var jToken = JObject.Parse(json)["id"];
            var jToken2 = JObject.Parse(json)["owner_id"];
            var jToken3 = JObject.Parse(json)["region"];
            var jToken4 = JObject.Parse(json)["vanity_url_code"];
            var jToken5 = JObject.Parse(json)["icon"];
            string value;
            if (jToken5 == null || string.IsNullOrEmpty(jToken5.ToString()))
            {
                value = "";
            }
            else
            {
                value = jToken5.ToString();
            }

            var jToken6 = JObject.Parse(json)["banner"];
            string value2;
            if (jToken6 == null || string.IsNullOrEmpty(jToken6.ToString()))
            {
                value2 = "";
            }
            else
            {
                value2 = jToken6.ToString();
            }

            string text;
            if (!string.IsNullOrEmpty(value))
            {
                text = $"https://cdn.discordapp.com/icons/{jToken}/{jToken5}.webp";
            }
            else
            {
                text = "N/A";
            }

            string text2;
            if (!string.IsNullOrEmpty(value2))
            {
                text2 = $"https://cdn.discordapp.com/banners/{jToken}/{jToken6}.webp?size=240";
            }
            else
            {
                text2 = "N/A";
            }

            object obj = JObject.Parse(json)["verification_level"];
            switch (obj as string)
            {
                case "0":
                    obj = "None";
                    break;

                case "1":
                    obj = "Low";
                    break;

                case "2":
                    obj = "Medium";
                    break;

                case "3":
                    obj = "High";
                    break;

                case "4":
                    obj = "Highest";
                    break;
            }
            var jToken7 = JObject.Parse(json)["preferred_locale"];
            var jToken8 = JObject.Parse(json)["nsfw"];
            var jArray = JArray.Parse(Request.Send($"/guilds/{gid}/roles", "GET", token));
            int num = 0;
            foreach (var item in jArray)
            {
                _ = item;
                num++;
            }
            var jArray2 = JArray.Parse(Request.Send($"/guilds/{gid}/channels", "GET", token));
            int num2 = 0;
            foreach (var item2 in jArray2)
            {
                _ = item2;
                num2++;
            }
            var jArray3 = JArray.Parse(Request.Send($"/guilds/{gid}/emojis", "GET", token));
            int num3 = 0;
            foreach (var item3 in jArray3)
            {
                _ = item3;
                num3++;
            }
            var jArray4 = JArray.Parse(Request.Send($"/guilds/{gid}/stickers", "GET", token));
            int num4 = 0;
            foreach (var item4 in jArray4)
            {
                _ = item4;
                num4++;
            }
            var jArray5 = JArray.Parse(Request.Send($"/guilds/{gid}/bans", "GET", token));
            int num5 = 0;
            foreach (var item5 in jArray5)
            {
                _ = item5;
                num5++;
            }
            var jArray6 = JArray.Parse(Request.Send($"/guilds/{gid}/invites", "GET", token));
            int num6 = 0;
            foreach (var item6 in jArray6)
            {
                _ = item6;
                num6++;
            }
            Console.ForegroundColor = Color.Yellow;
            Console.WriteLine("Guild Information:\n");
            Console.WriteLine($"Guild ID: {jToken}\nOwner ID: {jToken2}\nRegion: {jToken3}\nRoles Count: {num}\nChannels Count: {num2}\nEmojis Count: {num3}\nStickers Count: {num4}\nBans Count: {num5}\nInvites Count: {num6}\nVerification Level: {obj}\nPreferred Locale: {jToken7}\nNSFW: {jToken8}\nVanity Code: {jToken4}\nGuild Icon: {text}\nBanner: {text2}");
            Console.WriteLine("\nPress any key to go back.");
            Console.ReadKey();
            Console.Clear();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void CreateChannel(string token, ulong? gid, string name)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/guilds/{gid}/channels", "POST", token, "{\"name\":\"" + name + "\"}", XAuditLogReason: true);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void CreateRole(string token, ulong? gid, string name)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/guilds/{gid}/roles", "POST", token, "{\"name\":\"" + name + "\"}", XAuditLogReason: true);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteInvites(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/invites", "GET", token)))
            {
                Request.Send($"/invites/{item.code}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item.code}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteEmojis(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/emojis", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/emojis/{item.id}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item.name}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteChannels(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/channels", "GET", token)))
            {
                Request.Send($"/channels/{item.id}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item.name}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void RemoveBans(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/bans", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/bans/{item.user["id"]}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Removed: {item.user["username"]}#{item.user["discriminator"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteRoles(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/roles", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/roles/{item["id"]}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteStickers(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/stickers", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/stickers/{item["id"]}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static string GetGuildName(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            var jToken = JObject.Parse(Request.Send($"/guilds/{gid}", "GET", token))["name"];
            if (jToken != null)
            {
                return jToken.ToString();
            }
            return "N/A";
        }
        catch
        {
            return "N/A";
        }
    }

    public static void PruneMembers(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/guilds/{gid}/prune", "POST", token, "{\"days\": 1}", XAuditLogReason: true);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void RemoveIntegrations(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/integrations", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/integrations/{item["id"]}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteAllReactions(string token, ulong? cid, ulong? mid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/channels/{cid}/messages/{mid}/reactions", "DELETE", token);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteAutoModerationRules(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/auto-moderation/rules", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/auto-moderation/rules/{item["id"]}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void CreateInvite(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/channels", "GET", token)))
            {
                Request.Send($"/channels/{item.id}/invites", "POST", token, "{\"max_age\": 0}", XAuditLogReason: true);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteGuildScheduledEvents(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/scheduled-events", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/scheduled-events/{item.id}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteGuildTemplate(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/templates", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/templates/{item.code}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteStageInstances(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/channels", "GET", token)))
            {
                if (item.type == "13")
                {
                    Request.Send($"/stage-instances/{item.id}", "DELETE", token, null, XAuditLogReason: true);
                    Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                    Config.Sleep(Config.Wait.Short);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteWebhooks(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/webhooks", "GET", token)))
            {
                Request.Send($"/webhooks/{item.id}", "DELETE", token, null, XAuditLogReason: true);
                Console.WriteLine($"Deleted: {item["name"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteWebhook(string token, ulong? wid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/webhooks/{wid}", "DELETE", token, null, XAuditLogReason: true);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void SendWebhookMessage(string token, ulong? wid, string wtoken, string message)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/webhooks/{wid}/{wtoken}", "POST", token, "{\"content\":\"" + message + "\"}");
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void GrantEveryoneAdmin(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/roles", "GET", token)))
            {
                if (item.name == "@everyone")
                {
                    Request.Send($"/guilds/{gid}/roles/{item.id}", "PATCH", token, "{\"permissions\":\"8\"}", XAuditLogReason: true);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ReportMessage(string token, ulong? gid, ulong? cid, ulong? mid, int reason)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/report", "POST", token, $"{{\"channel_id\": \"{cid}\", \"guild_id\": \"{gid}\", \"message_id\": \"{mid}\", \"reason\": {reason}}}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }
}