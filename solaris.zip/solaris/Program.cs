﻿using OpenQA.Selenium.Chrome;
using Solaris.API;
using Solaris.API.Internals.Menues;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using WebDriverManager;
using WebDriverManager.DriverConfigs.Impl;
using Console = Colorful.Console;

namespace Solaris
{
    internal class Program
    {
        public static string token;

        public static readonly List<string> tokenlist = new List<string>();

        public static ulong? guildid;

        public static int count = 0;

        public static void Main()
        {
            Console.Title = "Solaris";
            try
            {
                Console.ForegroundColor = Color.GhostWhite;
                if (!File.Exists($@"{Path.GetTempPath()}\token.txt"))
                {
                    File.Create($@"{Path.GetTempPath()}\token.txt").Dispose();
                }
                if (!File.Exists("multitokens.txt"))
                {
                    File.Create("multitokens.txt").Dispose();
                }
                string value = File.ReadAllText($@"{Path.GetTempPath()}\token.txt");
                if (!string.IsNullOrEmpty(value))
                {
                    token = value;
                    try
                    {
                        Request.Send("/users/@me", "GET", token);
                    }
                    catch
                    {
                        Config.IsBot = true;
                    }
                }
                MainMewn.Show();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}\n\nPress any key to exit.");
                Console.ReadKey();
                Environment.Exit(0);
            }
        }

        public static void LoginToAccount()
        {
            try
            {
                new DriverManager().SetUpDriver(new ChromeConfig(), "MatchingBrowser");
                Console.WriteLine("Please wait");
                ChromeDriverService chromeDriverService = ChromeDriverService.CreateDefaultService();
                chromeDriverService.EnableVerboseLogging = false;
                chromeDriverService.SuppressInitialDiagnosticInformation = true;
                chromeDriverService.HideCommandPromptWindow = true;
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.AddArguments("--disable-logging", "--disable-extensions", "--disable-notifications", "--disable-application-cache", "--no-sandbox", "--disable-crash-reporter", "--disable-dev-shm-usage", "--ignore-certificate-errors", "--disable-infobars", "--silent");
                new ChromeDriver(chromeDriverService, chromeOptions)
                {
                    Url = "https://discord.com/login"
                }.ExecuteScript("let token = \"" + token + "\"; function login(token) { setInterval(() => { document.body.appendChild(document.createElement `iframe`).contentWindow.localStorage.token = `\"${token}\"` }, 50); setTimeout(() => { location.reload(); }, 2500); } login(token);");
            }
            catch (WebException ex) when (ex.Response is HttpWebResponse httpWebResponse && httpWebResponse.StatusCode == HttpStatusCode.NotFound)
            {
                Console.WriteLine("This feature only supports Google Chrome");
                Config.Sleep(Config.Wait.Long);
                MainMewn.Show();

                foreach (Process process in Process.GetProcessesByName("chromedriver"))
                {
                    process.Kill();
                }
            }
            catch (Exception ex2)
            {
                Console.WriteLine(ex2.Message);
                Config.Sleep(Config.Wait.Long);
                MainMewn.Show();
            }
        }
    }
}