﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Solaris.API;
using System;
using System.Drawing;
using System.Security.Authentication;
using WebSocketSharp;
using Console = Colorful.Console;

public class Raid
{
    public static void JoinGroup(string token, string code)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/invites/" + code, "POST", token);
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void LeaveGuild(string token, ulong? id)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/guilds/{id}", "DELETE", token);
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void SendMessage(string token, ulong? cid, string message)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/channels/{cid}/messages", "POST", token, "{\"content\":\"" + message + "\"}");
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void AddReaction(string token, ulong? cid, ulong? mid, string emoji)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/channels/{cid}/messages/{mid}/reactions/{emoji}/@me", "PUT", token);
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void LeaveGroup(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/channels/{gid}", "DELETE", token);
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void DMUser(string token, ulong? cid, string message)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/channels/{cid}/messages", "POST", token, "{\"content\":\"" + message + "\"}");
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void TriggerTyping(string token, ulong? cid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send($"/channels/{cid}/typing", "POST", token);
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void ReportMessage(string token, ulong? gid, ulong? cid, ulong? mid, int reason)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            Request.Send("/report", "POST", token, $"{{\"channel_id\": \"{cid}\", \"guild_id\": \"{gid}\", \"message_id\": \"{mid}\", \"reason\": {reason}}}");
            Console.WriteLine($"Succeed: {token}", Color.Lime);
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void Boost(string token, ulong? gid)
    {
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            var jArray = JArray.Parse(Request.Send("/users/@me/guilds/premium/subscription-slots", "GET", token));
            int num = 0;
            foreach (JToken item in jArray)
            {
                num++;
                if (num != 0)
                {
                    Request.Send($"/guilds/{gid}/premium/subscriptions", "PUT", token, $"{{\"user_premium_guild_subscription_slot_ids\":\"{num}\"}}");
                }
            }
            Config.Sleep(Config.Wait.Short);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void OnlineTokens(string token)
    {
        string token2 = token;
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            WebSocket ws = new WebSocket("wss://gateway.discord.gg/?v=10&encoding=json");
            ws.SslConfiguration.EnabledSslProtocols = SslProtocols.Tls12;
            ws.OnOpen += delegate
            {
                var value = new
                {
                    op = 2,
                    d = new
                    {
                        token = token2,
                        properties = new { os = "Windows 11", device = "Windows" }
                    }
                };
                ws.Send(JsonConvert.SerializeObject(value));
            };
            ws.Connect();
            ws.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token2}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }

    public static void JoinVC(string token, ulong? gid, ulong? vid)
    {
        string token2 = token;
        Console.ReplaceAllColorsWithDefaults();
        try
        {
            WebSocket ws = new WebSocket("wss://gateway.discord.gg/?v=10&encoding=json");
            ws.SslConfiguration.EnabledSslProtocols = SslProtocols.Tls12;
            ws.OnOpen += delegate
            {
                var value = new
                {
                    op = 2,
                    d = new
                    {
                        token = token2,
                        properties = new { os = "Windows 11", device = "Windows" }
                    }
                };
                ws.Send(JsonConvert.SerializeObject(value));
                var value2 = new
                {
                    op = 4,
                    d = new { guild_id = gid, channel_id = vid, self_mute = true, self_deaf = true }
                };
                ws.Send(JsonConvert.SerializeObject(value2));
            };
            ws.Connect();
            ws.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {token2}\nError: {ex.Message}", Color.Red);
            Config.Sleep(Config.Wait.Long);
        }
    }
}