﻿using Solaris.API.Internals.Menues;
using Solaris.API.Internals.Utils;
using System.Drawing;
using Console = Colorful.Console;

namespace Solaris.API.Internals.Modules.Account
{
    public class EditProfile
    {
        public static void Show()
        {
            Asci.Draw();
            Console.ForegroundColor = Color.GhostWhite;
            Console.Write("\r\n╔══╦════════════╗\r\n║##║ Name       ║\r\n╠══╬════════════╣\r\n║00║ None       ║\r\n║01║ Bravery    ║\r\n║02║ Brilliance ║\r\n║03║ Balance    ║\r\n╚══╩════════════╝\r\n");
            Console.WriteLine();
            Console.Write("Your choice (leave blank to skip): ");
            string hypesquad = Console.ReadLine();
            if (!string.IsNullOrEmpty(hypesquad))
            {
                User.ChangeHypeSquad(Program.token, hypesquad);
            }

            Asci.Draw();
            Console.ForegroundColor = Color.GhostWhite;
            Console.Write("Custom Status (leave blank to skip): ");
            string status = Console.ReadLine();
            if (!string.IsNullOrEmpty(status))
            {
                User.ChangeStatus(Program.token, status);
            }
            MainMewn.Show();
        }
    }
}