﻿using System.Drawing;
using Console = Colorful.Console;

namespace Solaris.API.Internals.Utils
{
    public static class Asci
    {
        public static void Draw()
        {
            Console.Clear();
            Console.WriteLine("");
            string[] asci = new string[]
            {
                "███████╗ ██████╗ ██╗      █████╗ ██████╗ ██╗███████╗\n",
                "██╔════╝██╔═══██╗██║     ██╔══██╗██╔══██╗██║██╔════╝\n",
                "███████╗██║   ██║██║     ███████║██████╔╝██║███████╗\n",
                "╚════██║██║   ██║██║     ██╔══██║██╔══██╗██║╚════██║\n",
                "███████║╚██████╔╝███████╗██║  ██║██║  ██║██║███████║\n",
                "╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝\n",
            };
            foreach (string s in asci)
            {
                Console.WriteWithGradient($"                             {s}", Color.Crimson, Color.GhostWhite, 6);
            }
            Console.WriteLine("");
        }
    }
}