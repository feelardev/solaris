﻿using Solaris.API.Internals.Menues;
using System.Drawing;
using System.IO;
using Console = Colorful.Console;

namespace Solaris.API.Internals.Utils
{
    public static class Validator
    {
        public static void Token()
        {
            if (!string.IsNullOrEmpty(Program.token))
            {
                return;
            }
            try
            {
                Console.Clear();
                Asci.Draw();
                Console.ForegroundColor = Color.GhostWhite;
                Console.WriteLine();
                Console.Write("Token: ");
                Program.token = Console.ReadLine();
                Program.token = Program.token.Replace("'", "");
                Program.token = Program.token.Replace("\"", "");
                if (!Request.Check(Program.token))
                {
                    Asci.Draw();
                    Console.WriteLine("Invalid token.");
                    Program.token = string.Empty;
                    Config.Sleep(Config.Wait.Long);
                    MainMewn.Show();
                }

                File.WriteAllText($@"{Path.GetTempPath()}\token.txt", Program.token);
                try
                {
                    Request.Send("/users/@me", "GET", Program.token);
                }
                catch
                {
                    Config.IsBot = true;
                }
                Console.Clear();
            }
            catch
            {
            }
        }

        public static void GuildID()
        {
            Token();
            if (Program.guildid.HasValue)
            {
                return;
            }
            try
            {
                Console.Clear();
                Asci.Draw();
                Console.ForegroundColor = Color.Yellow;
                Console.WriteLine();
                Console.Write("Guild ID: ");
                Program.guildid = ulong.Parse(Console.ReadLine());
                foreach (string item in Program.tokenlist)
                {
                    if (Guild.GetGuildName(item, Program.guildid) == "N/A")
                    {
                        Asci.Draw();
                        Console.WriteLine("Invalid ID or you're not in the guild.");
                        Program.guildid = ulong.Parse("");
                        Config.Sleep(Config.Wait.Long);
                        MainMewn.Show();
                    }
                }
                Console.Clear();
            }
            catch
            {
            }
        }

        public static void MultiTokens()
        {
            try
            {
                Console.Clear();
                Asci.Draw();
                string[] array = File.ReadAllLines("multitokens.txt");
                foreach (string item in array)
                {
                    if (!Program.tokenlist.Contains(item))
                    {
                        Program.count++;
                        Program.tokenlist.Add(item);
                    }
                }
                if (Program.count == 0)
                {
                    Asci.Draw();
                    Console.WriteLine("Paste your tokens in multitokens.txt file.");
                    Config.Sleep(Config.Wait.Long);
                    MainMewn.Show();
                }
                Console.Clear();
            }
            catch
            {
            }
        }
    }
}