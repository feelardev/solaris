﻿using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;

namespace Solaris.API
{
    public static class Request
    {
        public static string Send(string endpoint, string method, string auth, string json = null, bool XAuditLogReason = false)
        {
            HttpClient httpClient = new HttpClient();
            string str;
            if (Config.IsBot)
            {
                str = $"Bot {auth}";
            }
            else
            {
                str = auth;
            }

            httpClient.DefaultRequestHeaders.Add("Authorization", str);
            if (XAuditLogReason)
            {
                httpClient.DefaultRequestHeaders.Add("X-Audit-Log-Reason", "Phoenix Nuker");
            }

            HttpRequestMessage request = new HttpRequestMessage(new HttpMethod(method), $"https://discord.com/api/v{Config.APIVersion}{endpoint}");
            if (json != null)
            {
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");
            }

            HttpResponseMessage response;
            if (method != "GET")
            {
                response = httpClient.SendAsync(request).GetAwaiter().GetResult();
            }
            else
            {
                response = httpClient.GetAsync(request.RequestUri).GetAwaiter().GetResult();
            }

            response.EnsureSuccessStatusCode();
            Thread.Sleep(1000);
            return new StreamReader(response.Content.ReadAsStreamAsync().Result).ReadToEnd();
        }

        public static bool Check(string token)
        {
            try
            {
                try
                {
                    HttpClient httpClient = new HttpClient();
                    httpClient.DefaultRequestHeaders.Add("Authorization", token);
                    new HttpRequestMessage(new HttpMethod("GET"), $"https://discord.com/api/v{Config.APIVersion}/users/@me").Content = null;
                    httpClient.GetAsync($"https://discord.com/api/v{Config.APIVersion}/users/@me").GetAwaiter().GetResult().EnsureSuccessStatusCode();
                    return true;
                }
                catch
                {
                    HttpClient httpClient = new HttpClient();
                    httpClient.DefaultRequestHeaders.Add("Authorization", $"Bot {token}");
                    new HttpRequestMessage(new HttpMethod("GET"), $"https://discord.com/api/v{Config.APIVersion}/users/@me").Content = null;
                    httpClient.GetAsync($"https://discord.com/api/v{Config.APIVersion}/users/@me").GetAwaiter().GetResult().EnsureSuccessStatusCode();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}